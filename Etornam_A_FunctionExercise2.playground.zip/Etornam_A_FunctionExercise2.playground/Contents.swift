import UIKit
// parts of my sandwich
enum Sandwich: CaseIterable {
    
    case bottomBagel
    case avacado // mash until spreadable
    case salt
    case redOnion // must be freshly cut and It must be red onion!!
    case baconBits
    case eggs //scrambled
    case chilliFlakes
    case shreddedCheese // put on hot egg so it can melt
    case bellPeppers //season and cut thinly
    case topBagel
}
// opperation
let cadoBagel = Sandwich.allCases.count
print("This is my \(cadoBagel) layer bagel sandwich it has ")


for Sandwich in Sandwich.allCases {
print(Sandwich)
}
print ("You have to assemble in this order or else it won't be the best sandwich!")
